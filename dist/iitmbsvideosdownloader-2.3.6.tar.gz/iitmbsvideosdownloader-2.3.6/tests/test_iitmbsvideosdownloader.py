def test_practice():
    assert 2 == 2